let PermissionClassNamespace = {
    varUrlPostclassPath: 'permission_class/class_permission.php'
};