<?php 
class UserPermisssion
{
			function __construct($roll_id_from_user_table)
			{
				if ($roll_id_from_user_table != null) {
					$arr =  json_encode($this->getUserPermissions($roll_id_from_user_table));
				
					echo "<script>var permissions = $arr;</script>";
				}
			}

			function getUserPermissions($roleId) {
				$servername = "localhost";
				$username = "root";
				$password = "s@nds1@b";
				$database = "user_permissions";

				$conn = new mysqli($servername, $username, $password, $database);

				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				}

				// Prepare SQL statement to fetch permissions based on role ID
				$sql = "SELECT p.name
						FROM permissions p
						INNER JOIN role_permissions rp ON p.id = rp.permission_id
						WHERE rp.role_id = ?";

				// Prepare and execute the query
				$stmt = $conn->prepare($sql);
				$stmt->bind_param("i", $roleId);
				$stmt->execute();

				// Fetch the permissions
				$permissions = [];
				$result = $stmt->get_result();
				while ($row = $result->fetch_assoc()) {
					$permissions[] = $row['name'];
				}

				// Close the statement and database connection
				$stmt->close();
				$conn->close();

				// Return the permissions
				return $permissions;
			}// Close of Function
			
			function ActionRequest($action)
			{
				switch($action)
				{
					case 'AddNewPermission':
						$this->addNewEventToJS($_POST['eventName'],$_POST['className'],$_POST['dbValue']);
					break;
				}
			}
			
			function addNewEventToJS($eventName,$className,$dbValue="")
			{
		
					// Specify the path to your file
					$filename = '../js/permission.js';

					// Read the file into an array of lines
					$fileContent = file($filename);

					// Loop through each line to find and replace the line containing "// add_new_var"
					foreach ($fileContent as $key => $line) {
						if (strpos($line, '// add_new_var') !== false) {
							// Replace the line with new content
							$newLineToAdd = "\n\t"; // New line content with a newline character
							$fileContent[$key] = $newLineToAdd.'var '.$eventName.' = document.querySelectorAll(".'.$className.'");'; // Replace "new line to add" with your new content
							$fileContent[$key] .= $newLineToAdd."// add_new_var\n"; 
							break; // Stop searching after the line is replaced
						}
					}

					// Write the updated content back to the file
					file_put_contents($filename, implode('', $fileContent));
					
					
					// Loop through each line to find and replace the line containing "// adding_new_permission"
					foreach ($fileContent as $key => $line) {
						if (strpos($line, '// adding_new_permission') !== false) {
							// Replace the line with new content
							$newLineToAdd = "\n\t"; // New line content with a newline character
							$fileContent[$key] = $newLineToAdd.''.$eventName.'.forEach(function(obj) {if (!hasPermission("'.$dbValue.'")) {obj.style.display = "none";}});'; // Replace "new line to add" with your new content
							$fileContent[$key] .= $newLineToAdd."// adding_new_permission\n"; 
							break; // Stop searching after the line is replaced
						}
					}

					// Write the updated content back to the file
					file_put_contents($filename, implode('', $fileContent));
					

					// Optionally, you can return a response to the client
					echo "Main Permission Parameter Added";


			}
}// Close of Class

$obj = new UserPermisssion($_SESSION['USERROLLID'] ?? null);

$obj->ActionRequest($_POST['action'] ?? null);
?>