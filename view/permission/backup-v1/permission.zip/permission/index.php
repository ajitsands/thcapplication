<?php 
session_start();
$_SESSION['USERROLLID']= 2;
include_once('permission_class/class_permission.php');

//$obj->addNewEventToJS();
?>
<button class="addAction">Add</button>
<button class="editAction">Edit</button>
<button class="deleteAction">Delete</button>
<button class="listAction">List</button>
<button class="saveAction">Save</button>
<button class="printAction">Print</button>
<button class="exportToExcelAction">ExportToExcel</button>
<button class="exportToPDFAction">ExportToPDF</button>

<button class="addNewEventstoJS">Add Actions</button>
<a class="stockAction" href="">Click me </a>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="js/permission.js"></script>

<script>
    $(document).ready(function() {
        $(".addNewEventstoJS").click(function() {
            var additionalContent = $("#additionalContent").val();
            
            // Send the additional content to the server using AJAX
            $.ajax({
                url: 'permission_class/class_permission.php', // URL to the server-side script
                type: 'POST',
                data: {action: 'AddNewPermission',eventName:'handle_stock',className:'stockAction',dbValue:'Stock'},
                success: function(response) {
                    alert(response);
                },
                error: function(xhr, status, error) {
                    console.error("Error appending to file:", error);
                    alert("Error appending to file. Please try again later.");
                }
            });
        });
    });
    </script>