   $(document).ready(function() {

           
         function checkColumnValue(columnIndex, value) {
            var rows = dataTable.rows().data(); // Get all rows data
            console.log(rows);
            for (var i = 0; i < rows.length; i++) {
                var rowData = rows[i];
                var cellValue = rowData['name'];
                //console.log(cellValue);
                if (cellValue == value) {
                    // Value found in the column
                    console.log("Value exists in column " + columnIndex + " in row " + i);
                    return false;
                }
            }
    
            // Value not found in the column
            console.log("Value does not exist in column " + columnIndex);
            return true;
        }
        function capitalizeFirstLetter(str) {
            return str.charAt(0).toUpperCase() + str.slice(1);
        }
        function isAlphabetic(str) {
            // Regular expression to match only alphabetic characters
            const regex = /^[A-Za-z]+$/;
            return regex.test(str);
        }
        
        function commonValidations(controlValue)
        {
            if($.trim(controlValue)==='')
            {
                return 'Module/Control Name cannpt be blank';
            }
            //var columnIndexToCheck = 2; // Index of the column to check (0-based index)
            //var valueToCheck = "Print"; // Value to check
            var valueToCheck =  $.trim(controlValue);
            
            if (valueToCheck.indexOf(" ") !== -1 || valueToCheck.indexOf("'") !== -1) {
                return 'Please check your Module/Control Name';
            }
            
            if(!isAlphabetic(valueToCheck))
            {
                return 'Please check your Module/Control Name only Alphabets';
            }
            return true;
        }
        
        $(".addNewEventstoJS").click(function() {
            
            var validationStatus = commonValidations($('#moduleOrControlName').val());
            if(validationStatus!==true)
            {
                alert(validationStatus);
                Swal.fire({
                  title: "Validation",
                  text: validationStatus,
                  icon: "error"
                });
                return false;
            }
            
            var status = checkColumnValue(2, $('#moduleOrControlName').val()); // FirstParameter to check Which Column Second one is the value to check : String from textbox
            
            if(status===true)
            {
                
                var moduleOrControlName = capitalizeFirstLetter($('#moduleOrControlName').val());
                // Send the additional content to the server using AJAX
                $.ajax({
                    url: 'permission_class/class_permission.php', // URL to the server-side script
                    type: 'POST',
                    data: {action: 'AddNewPermission',dbValue: moduleOrControlName},
                    success: function(response) {
                        alert(response);
                        dataTable.ajax.reload();
                    },
                    error: function(xhr, status, error) {
                        console.error("Error appending to file:", error);
                        //alert("Error appending to file. Please try again later.");
                    }
                });
            }
            else
            {
                Swal.fire({
                  title: "Validation",
                  text: 'Module/Control Name already Exist..!',
                  icon: "error"
                });
              
            }
            
            
        });
    });