<?php

//load.php

$connect = new PDO('mysql:host=localhost;dbname=sianlab_blogger', 'sianlab_sianlab', 's@nds1@b');


$data = array();

$query = "SELECT * FROM tbl_customer  ORDER BY customer_id";

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

foreach($result as $row)
{
 $data[] = array(
  'id'   => $row["customer_id"],
  'title'   => $row["status"],
  'start'   => $row["booking_date"],
  'end'   => $row["booking_date"],
  'backgroundColor'   => $row["event_color"],
  'borderColor'   => $row["event_color"],
 
  
 );
}

echo json_encode($data);

?>
