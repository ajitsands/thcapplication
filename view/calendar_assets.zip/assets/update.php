<?PHP



$servername = "localhost";
	$username = "sianlab_sianlab";
	$password = "s@nds1@b";
	$dbname = "sianlab_blogger";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$sql = "UPDATE tbl_customer SET  booking_date='".$_POST['start']."' WHERE customer_id=".$_POST['id'];

	if ($conn->query($sql) === TRUE) {
		//echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	$conn->close();
	?>